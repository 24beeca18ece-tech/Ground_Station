# Rocket telemetry TX, matched to the ground station

`Rocket_Telemetry_TX/Rocket_Telemetry_TX.ino` replaces `5_tx_test.ino`.

## What was wrong with the old sketch (against the GCS source)
| Item | Old sketch | GCS needs | Now |
|---|---|---|---|
| Packet | `$id,036,msl,agl,...*` | `$2025ASI001,ROCKET,...22 fields...*XX` | exact ROCKET layout |
| Checksum | none (`*` only) | XOR of body, 2 hex digits | added |
| Line end | none | CR LF on XBee | added |
| Missing fields | no TEMP, PRESSURE, NAV_TIME, NAV_ALT, FSM, flags | all mandatory | all present |
| Units | gyro 1 dp, no hPa | PRESSURE hPa, ACC m/s2, GYRO deg/s | matched |
| Rate | 8 Hz, 1/3 each to RX, RX1, LoRa | 20 Hz, merged by PACKET_COUNT | 20 Hz, odd to RX1, even to RX2 |
| TX status | frame id 0 (none) | 0x89 / 0x8B tracked | frame ids 1..255, status counted per receiver |
| LoRa | sent with no setup (915 MHz default) | n/a | band/SF/BW/CR set at boot, 1 Hz beacon |
| Safety | no WDT, delay() calibration, unsequenced `Wire.read()` | | WDT, background calibration, ordered reads |

## Packet (example, 138 chars)
`$2025ASI001,ROCKET,66.72,1333,1372.28,828.81,19.14,8.05,102036.00,32.726600,74.857000,1681.1,10,-0.086,-0.057,9.826,0.05,-0.12,-0.08,5,0,0*5F`

Fields: TEAM_ID, PAYLOAD_TYPE, TIMESTAMP (s), PACKET_COUNT, ALTITUDE (m AGL), PRESSURE (hPa), TEMP (C), VOLTAGE (V), NAV_TIME, LAT, LON, NAV_ALT (m MSL), SATS, ACC XYZ (m/s2), GYRO XYZ (deg/s), FSM_STATE, SOLENOID, NICHROME.
LAT, LON, NAV_ALT, NAV_TIME are empty with no GNSS fix. ACC and GYRO are empty if the IMU has been dead for 0.5 s. The GCS accepts both.

## Flight states (GCS names)
0 BOOT (calibrating) | 2 LAUNCH_PAD | 3 ASCENT (accel > 3 g for 50 ms, needs +10 m within 2.5 s) | 4 DEPLOY (apogee: baro drops 3 m below max for 5 samples) | 5 DESCENT | 6 AEROBRAKE_RELEASE (400 m AGL) | 7 IMPACT (still for 3 s below 60 m).
These thresholds were tuned on a simulated flight, not your motor. Check them against the CDR numbers.

## Pinout and power
| Teensy 4.1 pin | Connects to | Notes |
|---|---|---|
| 8 (TX2) | XBee DIN (pin 3) | 3.3 V logic |
| 7 (RX2) | XBee DOUT (pin 2) | |
| 3V3 supply | XBee VCC (pin 1) | XB3 PRO draws up to ~220 mA on TX: own 3.3 V regulator (>= 500 mA), not the Teensy 3V3 pin. 100 nF + 10 uF at the module, 100 uF on the rail |
| 35 (TX8) | RYLR896 RXD | |
| 34 (RX8) | RYLR896 TXD | 3.3 V supply, ~140 mA on TX at 15 dBm; 100 nF + 10 uF at the module |
| 29 (TX7) | L89HA RX | NMEA, 9600 baud |
| 28 (RX7) | L89HA TX | 3.3 V, 100 nF + 10 uF at the module |
| 18 (SDA), 19 (SCL) | LSM6DSO32 (0x6A), BMP581 (0x47) | 3.3 V, 400 kHz, 4.7 kohm pull-ups to 3.3 V (use the pull-ups on the breakouts or one set, not four), 100 nF at each sensor |
| 24 (A10) | battery divider midpoint | 33 kohm from pack+, 10 kohm to GND, 100 nF to GND. 8.4 V gives 1.95 V |
| 4 | buzzer | if it draws more than ~4 mA use an NPN/MOSFET |
| 30 / 31 / 32 | LED R / G / B | 330 ohm series resistor each |

Common ground for everything. 2S pack (6.0 to 8.4 V) feeds the buck converters for the 3.3 V rails.

## Radio settings to confirm
XBee (all three radios): AP=1, BD=7 (115200), same ID (PAN), CH=0x0B (2405 MHz), PL=4, check ATNP is at least 0x96 (150), because the packet is up to ~146 bytes.
LoRa: the sketch sets 866.5 MHz, SF10, BW 125 kHz, CR 4/5, 15 dBm, network 6, address 1. The receiver (ESP32 side) must use the same band and parameters, and the RYLR896 factory band is 915 MHz.

## Things to confirm
1. XBee addresses in the sketch: RX1 = 0013A20042A09641, RX2 = 0013A20042A095F5. Your older notes list different ones. Use the 64-bit address printed on each ground XBee.
2. TEAM_ID is `2025ASI001` (the GCS default).
3. SOLENOID and NICHROME fields are 0 because this sketch drives no pyro outputs. Set `REPORT_EVENT_FLAGS_FROM_FSM = true` only to light the GCS recovery indicators on the bench.
4. LoRa carries a short beacon, not the full packet, because a 140 byte frame at SF10 takes about 3 s of airtime. The GCS does not ingest LoRa anyway. Because every packet goes over XBee, the GCS "every third packet is LoRa" gap logic simply sees no gaps.
5. Uplink commands: the rocket listens on the XBee for a single character. `A` starts telemetry, `B` stops it. They are absolute (not toggles), so sending from RX1, from RX2, or from both does the same thing. The sender address is not checked. `B` is refused between launch and landing (`ALLOW_STOP_IN_FLIGHT`). Telemetry is always ON after any reset. While stopped the packet counter does not advance, the LED alternates red/blue, and the LoRa recovery beacon keeps running. Any other text is ignored. The GCS EJECT button is for the CanSat and the rocket ignores it.

### Sending A / B from XCTU
The ground XBees run API mode, so the XCTU console needs a frame, not typed text.
Console, Add new frame, Frame type `0x00 - TX (Transmit) Request: 64-bit address`, Destination `000000000000FFFF` (broadcast, so it does not depend on the rocket's address), RF data `A` or `B` in ASCII mode, Frame ID 0, Send selected frame.
XCTU and the GCS cannot both open the same COM port: press DISCONNECT for that RX in the GCS, send, then reconnect. Use either RX.

## What was tested (PC rig, `pc_test/run_tests.sh`)
The real .ino compiled on a PC against simulated LSM6DSO32, BMP581, GNSS, XBee and LoRa, with AddressSanitizer and UBSan on. Its output went through the GCS's own `ApiFrameUnwrapper`, `FrameSplitter`, `parse_frame` and `PacketMerger`.
* Nominal flight: 4000 of 4000 packets accepted, 0 rejected, 0 implausible, 0 gaps, 20.00 Hz, states BOOT to IMPACT in order.
* Faults: IMU dead 2 s, baro dead 1.2 s, I2C bus stuck, UART buffer full 1 s, XBee silent 12 s, random garbage on all three serial inputs. Flight continued, bus and radio recovered, only the 20 packets sent while the UART buffer was full were lost.
* Commands: `B` from RX1, repeated from RX2, `A` from RX2 then RX1 (0x80, 0x81 and 0x90 receive frames), junk ignored, `B` in flight refused, `B`/`a` after landing. Stream stayed contiguous, 0 gaps.
* Power loss at 1500 m: resumes the flight from EEPROM without re-calibrating. After landing the flag is cleared, so the next boot calibrates.

## NOT tested
* Compiling in the Arduino IDE for Teensy 4.1 (this machine has no Teensy toolchain). Verify it on your laptop first.
* Real RF range, real sensor noise, the Watchdog_t4 reset itself (mocked), the exact RYLR896 AT replies.
