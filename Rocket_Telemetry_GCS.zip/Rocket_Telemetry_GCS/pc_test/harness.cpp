// PC harness: runs Rocket_Telemetry_TX.cpp against simulated hardware.
#include "Arduino.h"
#include <algorithm>
#include <random>
#include <string>
uint32_t g_ms = 0; int g_pinState[64] = {0}; int g_sclToggles = 0; bool g_sdaStuck = false;
uint16_t g_battRaw = 0;
HardwareSerial Serial, Serial2, Serial7, Serial8;
float g_acc[3] = {0, 0, 9.80665f}, g_gyr[3] = {0, 0, 0}, g_pa = 97000.f, g_tc = 25.f;
bool g_imuFail = false, g_baroFail = false; int g_wireBegins = 0;
uint8_t g_eeprom[4096]; uint32_t g_lastFeed = 0, g_maxFeedGap = 0; bool g_wdtOn = false;
#include "Wire.h"
#include "EEPROM.h"
TwoWire Wire; EEPROMClass EEPROM;
void feedHook() {}
#include "Rocket_Telemetry_TX.cpp"

static std::mt19937 rng(12345);
static double gauss(double s) { return std::normal_distribution<double>(0, s)(rng); }

// ---- truth model ----
static double tAlt = 0, tVel = 0; static double tOffset = 0;   // offset for resume scenario
static int phase = 0;   // 0 pad 1 boost 2 coast 3 drogue 4 main 5 landed
static double tPhaseStart = 0;
static double groundMsl = 300.0;
static void stepTruth(double t) {
  const double dt = 0.001;
  double a = 0; double spin = 0;
  switch (phase) {
    case 0: if (t >= 8.0) { phase = 1; tPhaseStart = t; } break;
    case 1: a = 100.0; spin = 30; tVel += a * dt; tAlt += tVel * dt; if (t - tPhaseStart >= 2.0) phase = 2; break;
    case 2: a = -9.80665; tVel += a * dt; tAlt += tVel * dt; if (tVel <= -25.0) { tVel = -25.0; phase = 3; } break;
    case 3: tVel = -25.0; tAlt += tVel * dt; if (tAlt <= 400.0) phase = 4; break;
    case 4: tVel = -7.0; tAlt += tVel * dt; if (tAlt <= 0.0) { tAlt = 0; tVel = 0; phase = 5; } break;
    default: tVel = 0; break;
  }
  double sf = 9.80665 + (phase == 1 ? 100.0 : 0.0);          // specific force, z up
  if (phase == 2) sf = 0.2;                                  // coast: near free fall
  g_acc[0] = (float)(gauss(0.15)); g_acc[1] = (float)gauss(0.15); g_acc[2] = (float)(sf + gauss(0.15));
  g_gyr[0] = (float)(gauss(0.15) + 0.8); g_gyr[1] = (float)(gauss(0.15) - 0.5); g_gyr[2] = (float)(gauss(0.15) + 0.3 + spin);
  double h = groundMsl + tAlt;
  g_pa = (float)(101325.0 * pow(1.0 - h / 44330.0, 5.255) + gauss(1.5));
  g_tc = (float)(28.0 - 0.0065 * tAlt);
}

static std::string ggaLine(double t) {
  bool fix = t >= 12.0;
  double alt = groundMsl + tAlt;
  char body[160];
  if (fix) snprintf(body, sizeof body, "GNGGA,%02d%02d%02d.00,3243.5960,N,07451.4200,E,1,10,0.9,%.1f,M,0.0,M,,", 10, 20, (int)(30 + t) % 60, alt);
  else snprintf(body, sizeof body, "GNGGA,102030.00,,,,,0,03,9.9,,M,,M,,");
  uint8_t cs = 0; for (char* p = body; *p; p++) cs ^= (uint8_t)*p;
  char out[200]; snprintf(out, sizeof out, "$%s*%02X\r\n", body, cs);
  return out;
}

// ---- radio sim ----
static size_t xbScan = 0, lrScan = 0;
static std::vector<uint8_t> xbAll; static std::string loraLog;
static bool radioDead = false; static int statusMode = 0;
static int g_txFramesSeen = 0;
static void radioSim() {
  auto& tx = Serial2.tx;
  while (true) {
    size_t i = xbScan;
    while (i < tx.size() && tx[i] != 0x7E) i++;
    if (i + 3 > tx.size()) { xbScan = i; break; }
    size_t len = ((size_t)tx[i + 1] << 8) | tx[i + 2];
    if (i + 3 + len + 1 > tx.size()) { xbScan = i; break; }
    xbAll.insert(xbAll.end(), tx.begin() + i, tx.begin() + i + 3 + len + 1);
    g_txFramesSeen++;
    uint8_t type = tx[i + 3], id = tx[i + 4];
    if (type == 0x10 && id != 0 && !radioDead) {
      std::vector<uint8_t> r;
      if (statusMode == 0) r = {0x7E, 0x00, 0x03, 0x89, id, 0x00};
      else r = {0x7E, 0x00, 0x07, 0x8B, id, 0xFF, 0xFE, 0x00, 0x00, 0x00};
      uint32_t s = 0; for (size_t k = 3; k < r.size(); k++) s += r[k];
      r.push_back((uint8_t)(0xFF - (s & 0xFF)));
      statusMode ^= 1;
      for (uint8_t b : r) Serial2.rx.push_back(b);
      // a GCS uplink command and a modem status frame, to prove they are ignored
      if (g_txFramesSeen % 400 == 0) { uint8_t m[] = {0x7E, 0x00, 0x02, 0x8A, 0x06, 0x6F}; for (uint8_t b : m) Serial2.rx.push_back(b); }
    }
    xbScan = i + 3 + len + 1;
  }
  auto& lt = Serial8.tx;
  for (;;) {
    size_t i = lrScan; while (i < lt.size() && lt[i] != '\n') i++;
    if (i >= lt.size()) break;
    loraLog.append((const char*)&lt[lrScan], i + 1 - lrScan);
    lrScan = i + 1;
    for (char c : std::string("+OK\r\n")) Serial8.rx.push_back((uint8_t)c);
  }
}

static void pushRx(const std::vector<uint8_t>& body) {
  std::vector<uint8_t> f = {0x7E, (uint8_t)(body.size() >> 8), (uint8_t)body.size()};
  f.insert(f.end(), body.begin(), body.end());
  uint32_t sum = 0; for (uint8_t b : body) sum += b; f.push_back((uint8_t)(0xFF - (sum & 0xFF)));
  for (uint8_t b : f) Serial2.rx.push_back(b);
}
// kind 0: 0x80 (64 bit src = RX1 or RX2), 1: 0x81 (16 bit src), 2: 0x90
static void sendCmd(const char* data, int kind, int src) {
  std::vector<uint8_t> b;
  if (kind == 0) { b = {0x80, 0x00,0x13,0xA2,0x00,0x42,0xA0,0x96,(uint8_t)(src ? 0xF5 : 0x41), 0x30, 0x00}; }
  else if (kind == 1) { b = {0x81, 0x00, (uint8_t)(src + 1), 0x30, 0x00}; }
  else { b = {0x90, 0x00,0x13,0xA2,0x00,0x42,0xA0,0x96,(uint8_t)(src ? 0xF5 : 0x41), 0xFF,0xFE, 0x01}; }
  for (const char* c = data; *c; c++) b.push_back((uint8_t)*c);
  pushRx(b);
}
int main(int argc, char** argv) {
  std::string scen = argc > 1 ? argv[1] : "nominal";
  double tEnd = argc > 2 ? atof(argv[2]) : 150.0;
  const char* eepIn = argc > 3 ? argv[3] : nullptr;
  const char* eepOut = argc > 4 ? argv[4] : nullptr;
  double startT = argc > 5 ? atof(argv[5]) : 0.0;     // truth time at power on (resume)
  memset(g_eeprom, 0xFF, sizeof g_eeprom);
  if (eepIn) { FILE* f = fopen(eepIn, "rb"); if (f) { fread(g_eeprom, 1, sizeof g_eeprom, f); fclose(f); } }
  g_battRaw = (uint16_t)(8.05 / BATT_CAL_FACTOR);
  bool inAir = startT > 0;
  if (inAir) {   // power-on in flight: truth already in the drogue descent phase
    phase = 3; tAlt = atof(argc > 6 ? argv[6] : "900"); tVel = -25;
  }
  setup();

  FILE* ev = fopen("events.csv", "w"); fprintf(ev, "t,truth_alt,state,agl_meas\n");
  uint8_t lastState = 255; uint32_t nextGga = 0;
  const uint32_t endMs = (uint32_t)(tEnd * 1000);
  for (g_ms = 1; g_ms < endMs; g_ms++) {
    double t = g_ms * 0.001 + (inAir ? 0.0 : 0.0);
    if (!inAir) stepTruth(t); else { stepTruth(t + 100.0); }
    // ---- fault injection ----
    if (scen == "faults") {
      g_imuFail = (t > 5 && t < 7);
      g_baroFail = (t > 35 && t < 36.2);
      if (t > 60 && t < 60.01) { g_sdaStuck = true; g_sclToggles = 0; }
      if (t > 60 && g_sdaStuck && g_sclToggles >= 18) g_sdaStuck = false;
      radioDead = (t > 100 && t < 112);
      Serial2.freeBytes = (t > 70 && t < 71) ? 0 : 1024;
      if (t > 40 && t < 41) for (int k = 0; k < 3; k++) Serial7.rx.push_back((uint8_t)(rng() & 0xFF));  // line noise
    }
    if (scen == "cmd") {
      // pad: stop from RX1 at 5 s, again from RX2 at 5.5 s (idempotent), start from RX2 at 7 s
      if (g_ms == 5000) sendCmd("B", 0, 0);
      if (g_ms == 5500) sendCmd("b\r", 0, 1);
      if (g_ms == 7000) sendCmd("A", 1, 1);
      if (g_ms == 7100) sendCmd("A", 2, 0);          // duplicate start from the other radio
      // junk that must be ignored
      if (g_ms == 7200) sendCmd("AB", 0, 0);
      if (g_ms == 7300) sendCmd("X", 0, 1);
      if (g_ms == 7400) sendCmd("", 0, 1);
      // in flight (ascent starts t=8): stop must be refused
      if (g_ms == 20000) sendCmd("B", 0, 0);
      // after landing: stop works again, start works again
      if (g_ms == 175000) sendCmd("B", 0, 1);
      if (g_ms == 180000) sendCmd("a", 0, 0);
    }
    if (scen == "fuzz") {
      for (int k = 0; k < 3; k++) { Serial2.rx.push_back((uint8_t)(rng() % 3 == 0 ? 0x7E : rng() & 0xFF)); Serial7.rx.push_back((uint8_t)(rng() % 4 == 0 ? "$*,\n"[rng()%4] : rng() & 0xFF)); Serial8.rx.push_back((uint8_t)(rng() & 0xFF)); }
      if (Serial2.rx.size() > 4000) Serial2.rx.clear();
    }
    if (scen == "badvalues") {
      // pressure out of range 1 s, accel garbage 1 s
      if (t > 20 && t < 21) g_pa = 5000.f;
      if (t > 22 && t < 23) { g_acc[0] = 3000.f; }
    }
    if (g_ms >= nextGga) { nextGga += 1000; for (char c : ggaLine(t)) Serial7.rx.push_back((uint8_t)c); }
    loop();
    radioSim();
    if (fsmState != lastState) { lastState = fsmState; fprintf(ev, "%.3f,%.1f,%u,%.1f\n", t, tAlt, (unsigned)fsmState, aglRaw); }
    if (g_ms % 1000 == 0) { /* keep tx vectors small */ }
  }
  fclose(ev);
  FILE* f = fopen("xbee_tx.bin", "wb"); fwrite(xbAll.data(), 1, xbAll.size(), f); fclose(f);
  f = fopen("lora_tx.txt", "w"); fputs(loraLog.c_str(), f); fclose(f);
  f = fopen("usb.log", "wb"); fwrite(Serial.tx.data(), 1, Serial.tx.size(), f); fclose(f);
  if (eepOut) { f = fopen(eepOut, "wb"); fwrite(g_eeprom, 1, sizeof g_eeprom, f); fclose(f); }
  printf("txOn=%d cmdOk=%lu refused=%lu ignored=%lu lastCmd=%c\n", (int)txEnabled, (unsigned long)cmdAccepted, (unsigned long)cmdRejected, (unsigned long)cmdIgnored, lastCmd);
  printf("scenario=%s end_state=%u packets=%lu sentX=%lu dropped=%lu maxFeedGap=%ums i2cRec=%lu xbRec=%lu imuF=%lu baroF=%lu loraSent=%lu loraReady=%d cfgErr=%u wire_begins=%d nmea=%lu/%lu okRX1=%lu okRX2=%lu failRX=%lu/%lu\n",
         scen.c_str(), fsmState, (unsigned long)packetCount, (unsigned long)txSentX, (unsigned long)txDropped, g_maxFeedGap,
         (unsigned long)i2cRecoveries, (unsigned long)xbeeRecoveries, (unsigned long)imuFailures, (unsigned long)baroFailures,
         (unsigned long)loraSent, (int)loraReady, loraCfgErrors, g_wireBegins, (unsigned long)nmeaGood, (unsigned long)nmeaBad,
         (unsigned long)statusOk[0], (unsigned long)statusOk[1], (unsigned long)statusFail[0], (unsigned long)statusFail[1]);
  return 0;
}
