#pragma once
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <cstdarg>
#include <deque>
#include <vector>
using std::isfinite;
#define HIGH 1
#define LOW 0
#define INPUT 0
#define OUTPUT 1
#define INPUT_PULLUP 2
extern uint32_t g_ms;
extern int g_pinState[64];
extern int g_sclToggles;
extern bool g_sdaStuck;
extern uint16_t g_battRaw;
inline uint32_t millis() { return g_ms; }
void feedHook();            // harness: called when delay() burns time
inline void delay(uint32_t ms) { g_ms += ms; feedHook(); }
inline void delayMicroseconds(uint32_t) {}
inline void pinMode(uint8_t, uint8_t) {}
inline void digitalWrite(uint8_t p, int v) {
  if (p == 19 && g_pinState[19] != v) g_sclToggles++;
  g_pinState[p] = v;
}
inline int digitalRead(uint8_t p) {
  if (p == 18) return (g_sdaStuck && g_sclToggles < 18) ? LOW : HIGH;
  return g_pinState[p];
}
inline uint16_t analogRead(uint8_t) { return g_battRaw; }
inline void analogReadResolution(int) {}
inline void analogReadAveraging(int) {}

struct HardwareSerial {
  std::deque<uint8_t> rx;
  std::vector<uint8_t> tx;
  int freeBytes = 1024;
  bool open = true;
  int begins = 0;
  void begin(uint32_t) { begins++; open = true; }
  void end() { open = false; }
  int available() { return (int)rx.size(); }
  int read() { if (rx.empty()) return -1; int v = rx.front(); rx.pop_front(); return v; }
  size_t write(const uint8_t* p, size_t n) { if (open) tx.insert(tx.end(), p, p + n); return n; }
  size_t write(uint8_t b) { return write(&b, 1); }
  size_t print(const char* s) { return write((const uint8_t*)s, strlen(s)); }
  size_t println(const char* s) { print(s); return print("\n"); }
  int printf(const char* fmt, ...) {
    char b[600]; va_list a; va_start(a, fmt); int n = vsnprintf(b, sizeof b, fmt, a); va_end(a);
    if (n > 0) write((const uint8_t*)b, (size_t)std::min(n, (int)sizeof b - 1)); return n; }
  int availableForWrite() { return freeBytes; }
  void addMemoryForWrite(void*, size_t) {}
  void addMemoryForRead(void*, size_t) {}
  explicit operator bool() const { return true; }
};
extern HardwareSerial Serial, Serial2, Serial7, Serial8;
