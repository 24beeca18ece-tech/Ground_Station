#pragma once
#include "Arduino.h"
extern uint8_t g_eeprom[4096];
struct EEPROMClass {
  template <typename T> void put(int a, const T& v) { memcpy(g_eeprom + a, &v, sizeof(T)); }
  template <typename T> void get(int a, T& v) { memcpy(&v, g_eeprom + a, sizeof(T)); }
};
extern EEPROMClass EEPROM;
