#pragma once
#include "Arduino.h"
extern uint32_t g_lastFeed, g_maxFeedGap; extern bool g_wdtOn;
struct WDT_timings_t { float trigger = 0; float timeout = 0; void (*callback)() = nullptr; };
struct WDT1 {};
template <class T> struct WDT_T4 {
  void begin(const WDT_timings_t&) { g_wdtOn = true; g_lastFeed = g_ms; }
  void feed() { uint32_t gap = g_ms - g_lastFeed; if (g_wdtOn && gap > g_maxFeedGap) g_maxFeedGap = gap; g_lastFeed = g_ms; }
};
