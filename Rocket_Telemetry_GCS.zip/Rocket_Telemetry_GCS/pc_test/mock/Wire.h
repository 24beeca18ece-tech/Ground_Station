#pragma once
#include "Arduino.h"
// Simulated LSM6DSO32 (0x6A) and BMP581 (0x47)
extern float g_acc[3], g_gyr[3], g_pa, g_tc;
extern bool g_imuFail, g_baroFail;
extern int g_wireBegins;
struct TwoWire {
  uint8_t addr = 0, reg = 0, buf[32]; int n = 0, pos = 0, wn = 0; bool ok = true;
  void begin() { g_wireBegins++; }
  void end() {}
  void setClock(uint32_t) {}
  bool present(uint8_t a) {
    if (g_sdaStuck && g_sclToggles < 18) return false;
    if (a == 0x6A) return !g_imuFail;
    if (a == 0x47) return !g_baroFail;
    return false;
  }
  void beginTransmission(uint8_t a) { addr = a; wn = 0; }
  size_t write(uint8_t v) { if (wn == 0) reg = v; wn++; return 1; }
  uint8_t endTransmission(bool = true) { return present(addr) ? 0 : 2; }
  uint8_t requestFrom(uint8_t a, uint8_t cnt) {
    if (!present(a) || cnt > 32) return 0;
    n = cnt; pos = 0;
    for (int i = 0; i < cnt; i++) buf[i] = 0;
    if (a == 0x6A) {
      if (reg == 0x0F) buf[0] = 0x6C;
      if (reg == 0x22) {
        for (int i = 0; i < 3; i++) {
          int16_t g = (int16_t)lroundf(g_gyr[i] / 0.070f);
          int16_t c = (int16_t)lroundf(g_acc[i] / ((32.0f / 32768.0f) * 9.80665f));
          buf[2 * i] = (uint8_t)g; buf[2 * i + 1] = (uint8_t)((uint16_t)g >> 8);
          buf[6 + 2 * i] = (uint8_t)c; buf[6 + 2 * i + 1] = (uint8_t)((uint16_t)c >> 8);
        }
      }
    } else {
      if (reg == 0x01) buf[0] = 0x50;
      if (reg == 0x1D) {
        int32_t t = (int32_t)lroundf(g_tc * 65536.0f);
        uint32_t p = (uint32_t)lroundf(g_pa * 64.0f);
        buf[0] = (uint8_t)t; buf[1] = (uint8_t)(t >> 8); buf[2] = (uint8_t)(t >> 16);
        buf[3] = (uint8_t)p; buf[4] = (uint8_t)(p >> 8); buf[5] = (uint8_t)(p >> 16);
      }
    }
    return cnt;
  }
  int available() { return n - pos; }
  int read() { return pos < n ? buf[pos++] : -1; }
};
extern TwoWire Wire;
