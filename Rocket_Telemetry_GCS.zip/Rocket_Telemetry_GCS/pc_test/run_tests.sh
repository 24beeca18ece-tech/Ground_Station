#!/bin/bash
# PC test rig: runs the real .ino against simulated sensors and pushes its radio
# output through the ground station's own parser.
# Usage: ./run_tests.sh /path/to/ground_station   (needs g++, python3, PyQt5)
set -e
GS=${1:?path to the ground_station folder}
HERE=$(cd "$(dirname "$0")" && pwd); W=$(mktemp -d); cd "$W"
cp "$HERE"/harness.cpp "$HERE"/verify_gcs.py "$HERE"/gen_prototypes.py .; cp -r "$HERE"/mock .
cp "$HERE"/../Rocket_Telemetry_TX/Rocket_Telemetry_TX.ino Rocket_Telemetry_TX.cpp
python3 gen_prototypes.py Rocket_Telemetry_TX.cpp Rocket_Telemetry_TX.cpp
sed -i "s#/home/claude/24beeca18ece-tech/ground_station#$GS#" verify_gcs.py
g++ -std=c++17 -O1 -g -fsanitize=address,undefined -fno-sanitize-recover=undefined -Imock harness.cpp -o harness
for sc in nominal faults badvalues fuzz cmd; do echo "== $sc"; ./harness $sc 200 | tail -1 | cut -c1-160; python3 verify_gcs.py | grep -E "stats|missing:|FSM|REJECT|IMPLAUS"; done
echo "== power loss in the air, then resume"
./harness nominal 60 "" e1.bin >/dev/null; ./harness resume 140 e1.bin e2.bin 1 1500 | tail -1 | cut -c1-80; python3 verify_gcs.py | grep -E "FSM"
