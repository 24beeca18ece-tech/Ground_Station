"""Feed the firmware's raw XBee TX bytes through the team's real GCS parsers."""
import sys, collections
sys.path.insert(0, "/home/claude/24beeca18ece-tech/ground_station")
from serial_worker import ApiFrameUnwrapper, FrameSplitter
from telemetry_packet import parse_frame, PacketError, FSM_STATES
from packet_merger import PacketMerger

data = open(sys.argv[1] if len(sys.argv) > 1 else "xbee_tx.bin", "rb").read()
MAC1 = bytes([0x00,0x13,0xA2,0x00,0x42,0xA0,0x96,0x41]); MAC2 = bytes([0x00,0x13,0xA2,0x00,0x42,0xA0,0x95,0xF5])

# 1. split the rocket's TX stream into API frames, validate the API checksum
frames, i, bad_api = [], 0, 0
while i < len(data):
    if data[i] != 0x7E: i += 1; continue
    ln = (data[i+1] << 8) | data[i+2]
    fd = data[i+3:i+3+ln]; ck = data[i+3+ln]
    if len(fd) != ln or ((sum(fd) + ck) & 0xFF) != 0xFF: bad_api += 1; i += 1; continue
    frames.append(fd); i += 4 + ln
print("API frames:", len(frames), "bad API checksums:", bad_api)

# 2. turn each 0x10 Transmit Request into the 0x80 Receive frame the ground radio would output
rx = {"RX1": bytearray(), "RX2": bytearray()}
types = collections.Counter(); maxpay = 0
for fd in frames:
    types[fd[0]] += 1
    assert fd[0] == 0x10 and fd[1] != 0, "must be a 0x10 request with non-zero frame id"
    assert fd[10:12] == b"\xff\xfe", "16 bit addr"
    dest = "RX1" if fd[2:10] == MAC1 else "RX2" if fd[2:10] == MAC2 else None
    assert dest, "unknown destination"
    payload = fd[14:]; maxpay = max(maxpay, len(payload))
    body = bytes([0x80]) + b"\x00\x13\xa2\x00\x42\xa0\x00\x01" + bytes([0x28, 0]) + payload   # rssi -40 dBm
    rx[dest] += bytes([0x7E, len(body) >> 8, len(body) & 0xFF]) + body + bytes([0xFF - (sum(body) & 0xFF)])
print("frame types:", dict(types), " largest RF payload:", maxpay, "bytes")

# 3. run through the GCS ingest chain exactly as serial_worker does it
merger = PacketMerger(hold_s=0.5, on_warning=lambda m: print("MERGER:", m))
stats = collections.Counter(); got = {}
for name, stream in rx.items():
    api, spl = ApiFrameUnwrapper(), FrameSplitter()
    for k in range(0, len(stream), 37):                       # awkward chunking on purpose
        chunk = api.feed(bytes(stream[k:k+37]))
        for fr in spl.feed(chunk):
            try:
                p = parse_frame(fr)
            except PacketError as e:
                stats["rejected_" + type(e).__name__] += 1; print("REJECT", e, fr); continue
            stats["parsed"] += 1
            if not p.is_plausible: stats["implausible"] += 1; print("IMPLAUSIBLE", p.implausible_reasons(), fr)
            stats["rocket"] += p.is_rocket
            stats["hasfix"] += p.has_fix
            got[p.packet_count] = p
            merger.add(p, name, now=p.mission_time_s)
    print(name, "api_ok", api.api_frames_ok, "api_err", api.api_frame_errors, "resyncs", spl.resyncs)
out = merger.flush()
print("stats:", dict(stats))
cnts = sorted(got)
print("packet_count range", cnts[0], "..", cnts[-1], "missing:", len(set(range(cnts[0], cnts[-1]+1)) - set(cnts)),
      "| merger emitted", len(out), "missing", merger.missing, "dups", getattr(merger, "duplicates", "?"))
# 4. content checks
ts = [got[c].mission_time_s for c in cnts]
dt = [b - a for a, b in zip(ts, ts[1:])]
print("TIMESTAMP step: min %.2f max %.2f mean %.3f s  (rate %.2f Hz)" % (min(dt), max(dt), sum(dt)/len(dt), len(dt)/(ts[-1]-ts[0])))
seq = []
for c in cnts:
    s = got[c].fsm_state
    if not seq or seq[-1] != s: seq.append(s)
print("FSM sequence seen by GCS:", [FSM_STATES[s] for s in seq])
alt = [got[c].altitude_m for c in cnts]; print("altitude min %.1f max %.1f m" % (min(alt), max(alt)))
ex = got[cnts[len(cnts)//3]]; print("sample:", ex.raw_frame)
print("sample len:", len(ex.raw_frame), "chars | team", ex.team_id, "| type", ex.payload_type, "| acc", ex.acc_x, ex.acc_z, "| sol/nic", ex.solenoid_fired, ex.nichrome_fired)
